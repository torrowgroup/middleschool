package pocket_Book.pocket_Book;

import java.util.Scanner;

public class Text {      //登录系统
	String user="admin";
	String passage="666666";
	public static void main(String[] args) {
		String user="admin";
		String passage="666666";
		Scanner scan = new Scanner(System.in);
		System.out.println("请输入你的用户名：");
		String username=scan.nextLine();
		System.out.println("请输入你的密码：");
		String password=scan.nextLine();
		if(user.equals(username)  &&  passage.equals(password)) {  //比较用户名和密码是否匹配
			System.out.println("登录成功");    //不足：未使用IO，不能修改密码，且不能存储多账户
			new Pocket_Book();
		}
		else {
			System.out.println("你的用户名或密码有误");
		}
	}
	@Override
	public int hashCode() {    //重写比较方法
		final int prime = 31;
		int result = 1;
		result = prime * result + ((passage == null) ? 0 : passage.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Text other = (Text) obj;
		if (passage == null) {
			if (other.passage != null)
				return false;
		} else if (!passage.equals(other.passage))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
	
	

}
