package pocket_Book.pocket_Book;

import java.util.ArrayList;
import java.util.Scanner;

class Pocket_Book {

	public ArrayList<Data> datalist = new ArrayList<Data>();
	public int count = 0;

	

	
	
	
	public Pocket_Book() {

		Scanner scan = new Scanner(System.in);
		IO io = new IO();         //调取txt文件
		io.load(this);

		printMenu();

		while (true) {         //为true时，是无限循环
			int choice = scan.nextInt();

			if (choice == 5) {
				io.save(this);
				System.out.println("成功退出系统，欢迎再次光临！");
				break;
			}
			switch (choice) {
			case 1:
				add_annal();    //增加数据
				break;
			case 2:
				find_annal();      //查找数据
				break;
			case 3:
				delete_annal();    //删除数据
				break;
			case 4:
				change_password();     //修改密码
				break;
			default:
				System.out.println("输入非法");
				printMenu();
				continue;
			}
		}

	}

	
	

	void printMenu() { // 打印菜单
		System.out.println("     增加账目--1");
		System.out.println("     查找帐目--2");
		System.out.println("     删除帐目--3");
		System.out.println("     修改密码--4");
		System.out.println("     退出系统--5");
	}

	
	
	
	void add_annal() { // 增加账目
		if (count < datalist.size() + 1) {
			Scanner scan = new Scanner(System.in);
			System.out.println("请输入金额：");
			String amount = scan.nextLine();
			System.out.println("请输入类别：支出/收入1" + "\n");
			String type = scan.nextLine();
			System.out.println("请输入类目：");
			String use = scan.nextLine();
			System.out.println("请输入日期：");
			String date = scan.nextLine();
			System.out.println("请输入备注：");
			String remarks = scan.nextLine();
			Data data = new Data(amount, type, use, date, remarks);
			datalist.add(data);
			count++;
			System.out.println("添加成功！");
			printAllData();
			printMenu();
		}

	}

	
	
	void delete_annal() { // 删除账目
		Scanner scan = new Scanner(System.in);
		while (true) {

			System.out.println("请输入你要删除的所需途径：/类别--1/用途--2/日期--3/返回主菜单--4");
			int choice = scan.nextInt();
			if (choice == 1) {
				System.out.println("请输入你要删除的类别");
				String type = scan.nextLine();
				int id = typeFind(type);
				if (id > -1) {
					datalist.remove(id);
					count--;
					System.out.println("删除成功！");
					printAllData();
				} else {
					System.out.println("未查找到您想要的类别");
				}
			} else if (choice == 2) {
				System.out.println("请输入你要删除的用途");
				String use = scan.nextLine();
				int id = useFind(use);
				if (id > -1) {
					datalist.remove(id);
					count--;
					System.out.println("删除成功！");
					printAllData();
				} else {
					System.out.println("未查找到您想要的用途");
				}
			} else if (choice == 3) {

				System.out.println("请输入你要删除的日期");
				String date = scan.next();
				int id = dateFind(date);
				if (id > -1) {
					datalist.remove(id);
					count--;
					System.out.println("删除成功！");
					printAllData();
				} else {
					System.out.println("未查找到您想要的日期");
				}
			} else if (choice == 4) {
				printMenu();
				break;
			} else {
				System.out.println("输入非法！");
			}
		}
		scan.close();

	}

	
	
	
	void find_annal() { // 查找账目
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("请输入您要查找的路径：/1.金额/2.类别/3.用途/4.日期/5.所有记录/6.返回主菜单");
			int choice = scan.nextInt();
			if (choice == 1) {
				System.out.println("请输入您要查找的金额：");
				String amount = scan.next();
				int id = amountFind(amount);
				new Pocket_Book().printData(id);

			} else if (choice == 2) {
				System.out.println("请输入您要查找的类别：");
				String type = scan.next();
				int id = typeFind(type);
				new Pocket_Book().printData(id);
			} else if (choice == 3) {
				System.out.println("请输入您要查找的用途：");
				String use = scan.next();
				int id = useFind(use);
				new Pocket_Book().printData(id);

			} else if (choice == 4) {
				System.out.println("请输入您要查找的日期：");
				String date = scan.next();
				int id = dateFind(date);
				new Pocket_Book().printData(id);
			} else if (choice == 5) {
				printAllData();
				break;
			} else if (choice == 6) {
				printMenu();
				break;
			} else {
				System.out.println("输入非法！");
			}

		}
	}

	
	
	
	void change_password() { // 修改密码
	}

	void printAllData() { // 打印所有账目记录
		for (int id = 0; id < count; id++) {
			Data data = (Data) datalist.get(id);
			System.out.println("[" + (id + 1) + "]" + "金额：" + data.get_Amount() + "  类别：" + data.get_Type() + "  用途："
					+ data.get_Use() + "  日期：" + data.get_Date() + "  备注：" + data.get_Remarks());
		}

	}

	
	
	
	int amountFind(String amount) { // 金额查找
		int id = -1;
		for (int i = 0; i < count; i++) {
			Data data = (Data) datalist.get(i);
			if (data.get_Amount().equals(amount)) {
				id = i; 
				break;
			} else if (i < count)
				continue;
			else {
				System.out.println("未查找到您想要的金额");
				break;
			}
		}
		return id;
	}

	
	
	
	int typeFind(String type) { // 类别查找
		int id = -1;
		for (int i = 0; i < count; i++) {
			Data data = (Data) datalist.get(i);
			if (data.get_Type().equals(type)) {
				id = i;
				break;
			} else if (i < count)
				continue;
			else {
				System.out.println("未查找到您想要的类别");
				break;
			}
		}
		return id;
	}

	
	
	
	int useFind(String use) { // 用途查找
		int id = -1;
		for (int i = 0; i < count; i++) {
			Data data = (Data) datalist.get(i);
			if (data.get_Use().equals(use)) {
				id = i;
				break;
			} else if (i < count)
				continue;
			else {
				System.out.println("未查找到您想要的用途");
				break;
			}
		}
		return id;
	}

	
	
	
	int dateFind(String date) { // 日期查找
		int id = -1;
		for (int i = 0; i < count; i++) {
			Data data = (Data) datalist.get(i);
			if (data.get_Date().equals(date)) {
				id = i;
				break;
			} else if (i < count)
				continue;
			else {
				System.out.println("未查找到您想要的日期");
				break;
			}
		}
		return id;
	}

	
	
	
	int remarksFind(String remarks) { // 类别查找
		int id = -1;
		for (int i = 0; i < count; i++) {
			Data data = (Data) datalist.get(i);
			if (data.get_Remarks().equals(remarks)) {
				id = i;
				break;
			} else if (i < count)
				continue;
			else {
				System.out.println("未查找到您想要的备注");
				break;
			}
		}
		return id;
	}

	
	
	
	void printData(int id) {
		if (id > -1) {
			for (int i = 0; i <= count; i++) {
				Data data = (Data) datalist.get(id);
				System.out.println("[" + (id + 1) + "]" + "金额：" + data.get_Amount() + "  类别：" + data.get_Type()
						+ "  用途：" + data.get_Use() + "  日期：" + data.get_Date() + "  备注：" + data.get_Remarks());
			}
		}
	}

}
