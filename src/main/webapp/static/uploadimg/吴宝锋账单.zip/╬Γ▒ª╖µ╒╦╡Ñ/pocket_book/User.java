package pocket_Book.pocket_Book;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;

class User {
	public void read() throws Exception{
		String pathname = "d:\\user.txt";   
        File file = new File(pathname); 
        if(!file.exists()) {
     	   file.createNewFile();
        }
        InputStreamReader reader = new InputStreamReader(  
                new FileInputStream(file));  
        BufferedReader br = new BufferedReader(reader);  
        String line = null;               
        while ((line=br.readLine())!= null) {                                   
            System.out.println(line);
        }  
	}
	
	public void coverWriter() throws Exception{
		 File file = new File("d:\\user.txt"); 
        if(!file.exists()) {
     	   file.createNewFile(); 
        }             
        BufferedWriter out = new BufferedWriter(new FileWriter(file));  //每次覆盖写入
        out.write("\r\n");                 
        out.write(48);
        out.flush(); 
        out.close(); 
	}
	
	private final String username="admin";
	private String password;

	public User(String user,String pass) {
		
	}
	public boolean check(userName,passWord) {
		if(username.equals(userName)  &&  password.equals(passWord)) {
			return true;
		}
		else {
			System.out.println("用户名或密码错误！！请重新输入。。");
			
		}
		
	}
	
	
	
	
	
	
 	
	
	
	
	public String get_Username() {
		return username;
	}
	public String get_Passage() {
		return password;
	}

}
