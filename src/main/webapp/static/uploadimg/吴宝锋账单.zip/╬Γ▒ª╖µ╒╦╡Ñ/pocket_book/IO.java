package pocket_Book.pocket_Book;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class IO {

	
	public void load(Pocket_Book pocket_book)//读取文件  
	    {  
	        try {  
	            String filename = "d:\\data.txt";  
	            File file = new File(filename); 
	            if(!file.exists()) {
	           	   file.createNewFile(); // 创建新文件  
	              }
	            BufferedReader reader = new BufferedReader(new FileReader(file));  
	            String temp;  
	            while((temp = reader.readLine()) != null )  
	            {  
	                String amount = temp.split(",")[0];  
	                String type = temp.split(",")[1];  
	                String use = temp.split(",")[2]; 
	                String date = temp.split(",")[3];
	                String remarks = temp.split(",")[4];
	                Data data = new Data(amount,use,type,date,remarks);  
	                pocket_book.datalist.add(data);  
	                pocket_book.count++;  
	            }  
	            reader.close();  
	        } catch (FileNotFoundException e) {  
	            e.printStackTrace();  
	        } catch (NumberFormatException e) { 
	            e.printStackTrace();  
	        } catch (IOException e) { 
	            e.printStackTrace();  
	        }  
	    }
	
	
	
	
	public void save(Pocket_Book pocket_book)//写入文件  
    {  
        String fileName = "d:\\data.txt";  
        String alldata="";  
        for(int i = 0; i < pocket_book.datalist.size(); i++)  
        {  
            Data data = (Data)pocket_book.datalist.get(i);  
            String temp = data.get_Amount() + "," + data.get_Type() + ","+ data.get_Use() + ","+ data.get_Date() + "," + data.get_Remarks() + "\r\n";  
            alldata += temp;  
        }  
        try {  
            File file1 = new File(fileName);  
            FileWriter fileWriter;  
            fileWriter = new FileWriter(file1);  
            fileWriter.write(alldata);  
            fileWriter.close();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
          
    }  
}