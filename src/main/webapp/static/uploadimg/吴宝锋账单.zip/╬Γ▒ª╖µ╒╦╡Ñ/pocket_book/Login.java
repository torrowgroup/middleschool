package pocket_Book.pocket_Book;

import java.util.Scanner;
class Login {
    public static void main(String[] args) {
        System.out.println("请输入用户名");
        Scanner sc  = new Scanner(System.in);
        String name = sc.nextLine();
        System.out.println("请输入密码");
        String pass  = sc.nextLine();
        sc.close();
        User cd = new User(name,pass);//用户名和密码传入验证类
        boolean bo = cd.check(name,pass);//调用方法进行验证
        if(cd.get_Username().equals(name)  &&  cd.get_Passage().equals(pass)){
            System.out.println("登录成功");
        }else{
            System.out.println("请重新输入用户名和密码！！");
        }
    }
    
}