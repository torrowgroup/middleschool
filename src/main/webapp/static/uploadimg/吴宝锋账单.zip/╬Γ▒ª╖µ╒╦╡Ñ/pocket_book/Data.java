package pocket_Book.pocket_Book;

class Data {
	
	
	private String amount;      //金额
    private String type;        //类别
    private String use;         //用途
    private String date;           //时间
    private String remarks;    //备注
  
    
    
	public Data(String amount,String type,String use,String date,String remarks) {
		this.amount=amount;
		this.type=type;
		this.use=use;
		this.date=date;
		this.remarks=remarks;
	}
  
    
	
	public String get_Amount() {
    	return amount;
    }
    public String get_Type() {
    	return type;
    }
    public String get_Use() {
    	return use;
    }
    public String get_Date() {
    	return date;
    }
    public String get_Remarks() {
    	return remarks;
    }    
    
  
    public void set_data(String amount,String type,String use,String date,String remarks) {
    	this.amount=amount;
		this.type=type;
		this.use=use;
		this.date=date;
		this.remarks=remarks;
    }
}
