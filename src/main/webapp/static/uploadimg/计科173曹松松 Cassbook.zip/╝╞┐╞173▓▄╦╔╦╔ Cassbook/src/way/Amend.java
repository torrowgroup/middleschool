package way;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
/*
 * 下面的方法为修改方法
 * 
 */
public class Amend {
	 //创建返回类对象
   Return re=new Return();                 
   public void Amen() throws IOException{
		String thisline;
		int count=0;
		FileReader der=new FileReader("D:\\test\\dat.java");
		BufferedReader buff=new BufferedReader(der);
		//创建集合，把集合作为中转站，帮其完成修改工作
		List <String>list=new ArrayList<String>();
		while((thisline=buff.readLine())!=null){
	    //把每一行依次存在集合的空位上
		  list.add(thisline);
		  count++;
		  System.out.println(thisline);
		}
		  buff.close();
		 
		  System.out.println("请输入要修改的流水号");
		  Scanner scan=new Scanner(System.in);
		  int number=scan.nextInt();
		  String s=list.get(number-1);
		  //把要修改的那一行删除掉
		  list.remove(number-1);
		  System.out.println("要修改的流水信息为:"+s);
		  Scanner su=new Scanner(System.in);
		  System.out.println("请输入修改金额:");
		  String sum=su.nextLine();
		  System.out.println("请输入修改金额的类型:");
		  Scanner ty=new Scanner(System.in);
		  String type=ty.nextLine();
		  System.out.println("请输入修改金额的条目:");
		  Scanner en=new Scanner(System.in);
		  String entry=en.nextLine();
//		  System.out.println("请输入该流水的行数:");
//		  Scanner numb=new Scanner(System.in);
//		  String numbe=numb.nextLine();
		  String hei=("流水"+" "+number+"["+"金额:"+sum+"  类型:"+type+"  条目:"+entry+"  流水号:"+"]");
		  System.out.println(hei);
		  //再把修好的一行信息存入集合，还是存到删除那一行的位置上，完成修改工作
		  list.add(number-1,hei);
		  System.out.println(list);
		  System.out.println("修改成功！");
		  
		  BufferedWriter buff1=new BufferedWriter(new FileWriter("D:\\test\\dat.java"));
		  //创建迭代器把每一行都赋给String s,再用输出流把现在集合中的流水信息都写到文件里;
		  for(String ad : list){
			  System.out.println(ad);
			 buff1.write(ad);
			 buff1.newLine();
		}
		     buff1.close();
   }
   /*
    * 下面是实现查询的方法
    */
   public void Inquire() throws IOException{
	   String thislin;
	   int count=0;
	    BufferedReader buff=new BufferedReader(new FileReader("D:\\test\\dat.java"));
	    List <String>li=new ArrayList<String>();
	    while((thislin=buff.readLine())!=null){
			  li.add(thislin);
			  count++;
			  System.out.println(thislin);
			   }

	    Query cha=new Query();
	    cha.Inquire();

	    }
}
