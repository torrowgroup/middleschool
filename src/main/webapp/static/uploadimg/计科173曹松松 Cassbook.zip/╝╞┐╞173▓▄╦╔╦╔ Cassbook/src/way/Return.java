package way;
/*
 * 此类中都是一些返回方法，在
 * 执行完功能后，用于返回上一级或退出本次登录
 * 用switch与do while实现此功能
 */
import java.io.IOException;
import java.util.Scanner;

import practical.Homepage;

public class Return {
     @SuppressWarnings("resource")
     //这是返回主菜单的方法
	public void Retu() throws Exception{
    	 Scanner reader=new Scanner(System.in);
    	 System.out.println("*  输入1，返回主菜单");
    	 System.out.println("*  输入2，退出本次登陆");
    	 int song;
    	 System.out.print("*请输入选项:");
    do{
    	 song=reader.nextInt();
    	 switch(song)
    	 {
    	 case 1:
    		 Homepage zhu=new Homepage();
    		 System.out.println("*已进入主菜单");
    		 zhu.Zhu();
    		 break;
    	 case 2:
    		 System.out.println("*已退出本次登陆");
    		 break;
    	 }
    	 if(song!=1&&song!=2)
    		 System.out.print("*请重新输入选项:");
    	 }while(song!=1&&song!=2);
     }
    public void Retu1() throws Exception{
    	 Data da=new Data();
    	 Scanner read=new Scanner(System.in);
    	 System.out.println("*  输入1，继续删除");
    	 System.out.println("*  输入2，退出删除");
    	 System.out.println("*请输入选项:");
    	 int son;
     do{
    	 son=read.nextInt();
    	 switch(son){
    	 
    	 case 1:
    		 da.Delete();
    		 break;
    	 case 2:
    		 System.out.println("*退出删除");
    	 }
    	 if(son!=1&&son!=2)
    		 System.out.print("*请重新输入选项:");
    	 }while(son!=1&&son!=2);
    }
    public void Retu2() throws Exception{
        Data da=new Data();
        Scanner read=new Scanner(System.in);
        System.out.println("您确定删除吗？");
        System.out.println("*  1: 确定");
        System.out.println("*  2: 不确定");
        System.out.println("*请输入选项:");
        int son;
    do{
        son=read.nextInt();
        switch(son){
        case 1:
        	System.out.println("确定");
        	System.out.println("继续进行删除");
        	System.out.println("删除成功！");
        	break;
        case 2:
        	System.out.println("不确定");
        	System.out.println("*  1: 进入删除界面");
        	System.out.println("*  2: 进入主菜单");
        	System.out.print("*请输入选项:");
        	int so;
        do{
            so=read.nextInt();
        	switch(so){
        	case 1:
        		da.Delete();
        		break;
        	case 2:
        		Homepage zhu=new Homepage();
        	    zhu.Zhu();
        	    break;
        	    }
        	    if(so!=1&&so!=2)
                System.out.print("*请重新输入选项:");
                }while(so!=1&&so!=2); 
            }
        	if(son!=1&&son!=2)
            System.out.print("*请重新输入选项:");
        	}while(son!=1&&son!=2); 
    }
    public void Retu3() throws IOException{
    	 Amend da=new Amend();
    	 @SuppressWarnings("resource")
		 Scanner read=new Scanner(System.in);
    	 System.out.println("*  输入1，继续查询");
    	 System.out.println("*  输入2，退出查询");
    	 int son;
    do{
    	 son=read.nextInt();
    	 switch(son){
    	 case 1:
    		 da.Inquire();
    		 break;
    	 case 2:
    		 System.out.println("退出查询");
    		 break;
    	 }
    	 if(son!=1&&son!=2)
         System.out.print("*请重新输入选项:");
         }while(son!=1&&son!=2); 
    }
   public void Retu4() throws Exception{
     Data ta=new Data();
     Scanner read=new Scanner(System.in);
   	 System.out.println("输入1，继续录入");
   	 System.out.println("输入2，退出录入");
   	 int son;
   do{
   	 son=read.nextInt();
   	 switch(son){
   	 case 1:
   		 ta.Choose();
   		 break;
   	 case 2:
   		 System.out.println("退出录入");
   		 break;
   	 }
   	 if(son!=1&&son!=2)
         System.out.print("*请重新输入选项:");
         }while(son!=1&&son!=2); 
    }
	public void Retu5() throws Exception{
   	 Scanner reader=new Scanner(System.in);
   	 System.out.println("*  输入1，继续修改");
   	 System.out.println("*  输入2，返回主菜单");
   	 System.out.println("*  输入3，退出本次登陆");
   	 int song;
   	 System.out.print("*请输入选项:");
   do{
   	 song=reader.nextInt();
   	 switch(song)
   	 {
   	 case 1:
   		 Passwords pass=new Passwords();
   		 pass.Xiugai();
   		 break;
   	 case 2:
   		 Homepage zhu=new Homepage();
   		 System.out.println("*已进入主菜单");
   		 zhu.Zhu();
   		 break;
   	 case 3:
   		 System.out.println("*已退出本次登陆");
   		 break;
   	 }
   	 if(song!=1&&song!=2)
   		 System.out.print("*请重新输入选项:");
   	 }while(song!=1&&song!=2);
    }
	 public void Retu6() throws Exception{
	     Forget ta=new Forget();
	     Scanner read=new Scanner(System.in);
	   	 System.out.println("输入1:返回开始页面");
	   	 System.out.println("输入2:退出本次登录");
	   	 int son;
	   do{
	   	 son=read.nextInt();
	   	 switch(son){
	   	 case 1:
	   		 System.out.println("已返回开始界面");
	   		 ta.forge();
	   		 break;
	   	 case 2:
	   		 System.out.println("已退出本次登录");
	   		 break;
	   	 }
	   	 if(son!=1&&son!=2)
	         System.out.print("*请重新输入选项:");
	         }while(son!=1&&son!=2); 
	    }
}
