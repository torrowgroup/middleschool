package way;

import java.io.FileReader;
import java.util.Scanner;

import practical.Land;
import control.Landing;

public class Forget {
	Scanner sca = new Scanner(System.in);
    Return re=new Return();//创建返回类的对象，调用想调用的方法
	public void forge() throws Exception {
		System.out.println("*  1:登录");
		System.out.println("*  2:忘记密码");
		System.out.print("你想进行的操作是:");
		String a;
		Landing de = new Landing();
		Land den = new Land();
		do{
		a = sca.nextLine();
		switch (a) {
		case "1":
			de.Deng();
			break;
		case "2":
			System.out.println("请回答问题");
			Scanner sc = new Scanner(System.in);
			System.out.println("我的女神是？");
			String huida = sc.nextLine();
			if (huida.equals("高圆圆")) {
				Passwords fa = new Passwords(); // 重置密码的对象
				//用流对文件进行操作，是其中的数据输出，获得其值
				FileReader fi=new FileReader("D:\\test\\shuju.java");
				char[] ch=new char[1000];
				int b=fi.read(ch);
				String st=new String(ch,0,b);
				System.out.println("已找回密码");
				System.out.println("你的密码是: " + st) ;
				System.out.println("请牢记你的密码！");
				re.Retu6();//用于判断是否返回开始页面还是退出本次登陆
			} else
				System.out.println("回答错误,找回密码失败");
			re.Retu6();
			break;
		}
		if(!a.equals("1")&&!a.equals("2"))
   		 System.out.print("*请重新输入选项:");
   	 }while(!a.equals("1")&&!a.equals("2"));
		}
	
}
