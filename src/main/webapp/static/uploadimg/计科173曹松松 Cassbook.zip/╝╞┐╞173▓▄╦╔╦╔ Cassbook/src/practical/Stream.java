package practical;
//这是封装流水属性的类

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class Stream implements Serializable {
	public String type; // 类型
	public String entry; // 条目
	public Double sum; // 金额
	public String time; // 时间

	public Stream(String type, String entry, Double sum, String time) {
		this.type = type;
		this.entry = entry;
		this.sum = sum;
		this.time = time;
	}

	@Override
	public String toString() {
		return "Stream [type=" + type + ", entry=" + entry + ", sum=" + sum
				+ ", time=" + time;
	}

	public Stream() {
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getEntry() {
		return entry;
	}

	public void setEntry(String entry) {
		this.entry = entry;
	}

	public Double getSum() {
		return sum;
	}

	public void setSum(Double sum) {
		this.sum = sum;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
}
