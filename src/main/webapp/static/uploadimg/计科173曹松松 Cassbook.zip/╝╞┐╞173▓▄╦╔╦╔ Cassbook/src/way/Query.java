package way;
/*
 * 这是实现查询功能的类
 * 主要运用了split的知识
 * 通过分割，获得具有形同部分的信息
 * 实现查询
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import practical.Stream;

public class Query {
	//创建返回类的对象re
	 Return re=new Return();
	 //创建String型变量，用于接受从文件中读取的每一行数据信息
	 String thislin;
	 String stream="stream";   
     String sum1="金额:";
     String type1=" 类型:";
	 String entry1=" 条目:";
     String time1=" 时间:";
	 public void Inquire() throws IOException{
	 Scanner read=new Scanner(System.in);
     System.out.println("&&&&&  1:按时间查询");
     System.out.println("&&&&&  2:按类型查询");
	 System.out.println("&&&&&  3:按条目查询");
	 System.out.println("&&&&&  4:按金额查询");
	 System.out.println("&&&&&  5:全部查询");
	 System.out.println("*请输入选项");
	 int in;
	 do{
	 in=read.nextInt();
	 switch(in){
		case 1:
			readOne();
			break;
		case 2:
			readThree();
			break;
		case 3:
			readFirst();
			break;
		case 4:
			readTwo();
			break;
		case 5:
			queryjudgment3();
			break;
		}
	 if(in!=1&&in!=2&&in!=3&&in!=4&&in!=5)
		 System.out.println("请重新输入");
	 }while(in!=1&&in!=2&&in!=3&&in!=4&&in!=5);
	 }
	 /*
	  * 这是实现按时间查询的方法
	  */
	 public void readOne() {
		    String  thisline;
	 try {
		    FileReader file=new FileReader("d:\\test\\dat.java");
		    BufferedReader bfile = new BufferedReader(file);
		    String[] s=null ;
		    String time0 = null;
		    Scanner sc=new Scanner(System.in);
		    System.out.print("查询时间:");
		    time0=sc.nextLine();
		   
	       while((thisline=bfile.readLine())!=null) {
			s = thisline.split(time1+time0);
			for(int i = 0;i < s.length; i++){
			if(i < s.length - 1)
		    System.out.println(s[i]+time1+time0+s[i+1]);
	        }
		    } re.Retu3();
		    }catch(IOException  e) {}
		    }
          /*
           * 这是实现按金额查询的方法
           */
	  public void readTwo() {
	          String  thisline;
		      int count=0;
              try {
	          FileReader file=new FileReader("d:\\test\\dat.java");
	          BufferedReader bfile = new BufferedReader(file);
	          String[] s=null ;
	          String money0 = null;
	          Scanner sc=new Scanner(System.in);
	          System.out.print("查询金额:");
	          money0=sc.nextLine();
	          while((thisline=bfile.readLine())!=null) {
	          //用split分割数据信息，提取要查询的指定信息，在读取过程中把具有此指定信息的那些行数据输出
		      s= thisline.split(sum1+money0);
		      for(int i = 0;i < s.length; i++){
	          if(i < s.length - 1)
	          System.out.println(s[i]+sum1+money0+s[i+1]);
	          }
	          }re.Retu3(); 
	          }catch(IOException  e) {}
	          }
	  /*
	   * 这是实现按类型查询的方法
	   */
		 public void readThree() throws IOException{
			  BufferedReader buff2=new BufferedReader(new FileReader("D:\\test\\dat.java"));
			  Scanner read2=new Scanner (System.in);
			  System.out.print("请输入查询的流水类型:");
			  String str1=read2.nextLine();
			  while((thislin=buff2.readLine())!=null){
			  String[] s=thislin.split(type1+str1);
			  for(int j=0;j<s.length;j++){
			  if(j<s.length-1)
			  System.out.println(s[j]+type1+str1+s[j+1]);
					   }
					}
			  buff2.close();
			  re.Retu3();
		 }
		 /*
		  * 这是实现按条目查询的方法
		  */
		 public void readFirst() throws IOException{
			  BufferedReader buff2=new BufferedReader(new FileReader("D:\\test\\dat.java"));
			  Scanner read2=new Scanner (System.in);
			  System.out.print("请输入查询的流水条目:");
			  String str1=read2.nextLine();
			  while((thislin=buff2.readLine())!=null){
			  String[] s=thislin.split(entry1+str1);
			  for(int j=0;j<s.length;j++){
			  if(j<s.length-1)
			  System.out.println(s[j]+entry1+str1+s[j+1]);
					   }
					}
			  buff2.close();
			  re.Retu3();
		}
		 /*
		  * 这是实现全部查询的方法
		  */
		public void queryjudgment3() throws IOException   {
			  String thisLine;
			  int count=0;
	    	  try {
	    	  FileReader read1=new FileReader("D:\\test\\dat.java");
	    	  BufferedReader bu=new BufferedReader(read1);
	    	  while((thisLine=bu.readLine())!=null){
	    	  count++;
	    	  System.out.println(thisLine);
	    	  }
	    	  System.out.println("共有"+count+"行");
	    	  read1.close();
	    	  re.Retu3();
	    	  }
	          catch(IOException  e) {}
		}
        }