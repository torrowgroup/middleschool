package practical;
//一个无关紧要的接口，，，
public interface LandInterfase {
	public abstract void setPassword(String g);
}
