package way;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import practical.Stream;

public class Data implements java.io.Serializable {

	static Stream str = new Stream();
	Return re = new Return();
	List<String> list = new ArrayList<String>();
    /*
     * 这是实现删除功能的方法
     */
	public boolean Delete() throws Exception {
		String thisline;
		int count = 0;
		FileReader der = new FileReader("D:\\test\\dat.java");
		BufferedReader buff = new BufferedReader(der);
		while ((thisline = buff.readLine()) != null) {
			list.add(thisline);
			count++;
			System.out.println(thisline);
		}
		buff.close();
		System.out.println("请输入要删除流水的行數");
		Scanner scan = new Scanner(System.in);
		int number = scan.nextInt();
		String sa = list.get(number - 1);
		System.out.println("被删除的流水信息为: " + sa);

		list.remove(number - 1);
		// String stri=null;
		re.Retu2();
		// List<String> la=new ArrayList<String>();
		// for(int i=0;i<list.size();i++){
		// String[] sam=list.get(i).split("流水");
		// for(int k=0;k<sam.length;k++){
		// if(k<sam.length-1)
		// System.out.print(sam[k+1]);
		// stri=sam[k];
		// la.add(stri);
		// }
		// }
		BufferedWriter buff1 = new BufferedWriter(new FileWriter(
				"D:\\test\\dat.java"));
		// 创建迭代器把每一行都赋给String s,再用输出流把现在集合中的流水信息都写到文件中;
		// int z=1;
		for (String s : list) {
			// System.out.println(s);
			buff1.write(s);
			buff1.newLine();
			// z++;
		}
		buff1.close();
		re.Retu1();
		return true;
	}
    //这是重新封装的写入方法
	public static String Write(Double sum, String type, String entry,
			String time) {
		FileWriter fo = null;
		BufferedWriter out = null;
		String str;
		//创此集合的目的是利用集合的长度来实现流水号nunber的自动添加
		List li = new ArrayList();
		File file1 = new File("D:\\test\\dat.java");
		try {
			BufferedReader bu = new BufferedReader(new FileReader(file1));
			while ((str = bu.readLine()) != null) {
				li.add(str);
			}
			String sum1 = "金额:";
			String type1 = " 类型:";
			String entry1 = " 条目:";
			String time1 = " 时间:";
			fo = new FileWriter(file1, true);
			out = new BufferedWriter(fo);
			out.write("流水" + " " + (li.size() + 1) + " " + "[" + sum1 + sum
					+ "\t" + type1 + type + "\t" + entry1 + entry + "\t"
					+ time1 + time + "]");
			out.newLine();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				out.flush();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;

	}

	/*
	 * 
	 * 录入功能的实现方法
	 */
	public static String entry;
	public static String type;

	public static void Choose() throws Exception {
		Scanner rea = new Scanner(System.in);

		System.out.println("——————————————温馨提示：输入金额请以数字格式输入——————————");
		System.out.print("请输入金额");
		boolean b = true;
		Double sum = null;
		//利用布尔数据使数值满足条件时结束while语句
		while (b) {
			try {
				sum = rea.nextDouble();
				b = false;
			} catch (Exception e) {
				System.out.print("你输入的格式有误，请输入数字:");
				rea.nextLine();
			}
		}
		System.out.println("请输入类型");
		System.out.println(" &&&&& 1: 支出 ");
		System.out.println(" &&&&& 2: 收入 ");
		System.out.print("请选择记录金额的类型:");
		Scanner choose = new Scanner(System.in);
		int choo;
		do {
			choo = choose.nextInt();
			switch (choo) {
			case 1:
				type = "支出";
				System.out.println(type);
				System.out.println(" &&&&& 1: 三餐支出");
				System.out.println(" &&&&& 2: 生活用品支出");
				System.out.println(" &&&&& 3: 朋友往来支出");
				System.out.println(" &&&&& 4: 其他支出");
				System.out.print("请输入条目:");
				int cho;
				do {
					cho = choose.nextInt();
					switch (cho) {
					case 1:
						entry = "三餐支出";
						System.out.println(entry);
						break;
					case 2:
						entry = "生活用品支出";
						System.out.println(entry);
						break;
					case 3:
						entry = "朋友往来支出";
						System.out.println(entry);
						break;
					case 4:
						entry = "其他支出";
						System.out.println(entry);
						break;
					}
					if (cho != 1 && cho != 2 && cho != 3 && cho != 4)
						System.out.print("请重新输入:");
				} while (cho != 1 && cho != 2 && cho != 3 && cho != 4);
				break;
			case 2:
				type = "收入";
				System.out.println("收入");
				System.out.println(" &&&&& 1: 工作薪水收入");
				System.out.println(" &&&&& 2: 闲余外快收入");
				System.out.println(" &&&&& 3: 朋友往来收入");
				System.out.println(" &&&&& 4: 其他收入");
				System.out.print("请输入条目:");
				int c;
				do {

					c = choose.nextInt();
					switch (c) {
					case 1:
						entry = "工作薪水收入";
						System.out.println(entry);
						break;
					case 2:
						entry = "闲余外快收入";
						System.out.println(entry);
						break;
					case 3:
						entry = "朋友往来收入";
						System.out.println(entry);
						break;
					case 4:
						entry = "其他收入";
						System.out.println("其他收入" + entry);
						break;
					}
					if (c != 1 && c != 2 && c != 3 && c != 4)
						System.out.print("请重新输入:");
				} while (c != 1 && c != 2 && c != 3 && c != 4);
			}
			break;
		} while (choo != 1 && choo != 2);
		System.out.println("*  1:自动生成此时时间");
		System.out.println("*  2:自己手动记录时间");
		Scanner sa = new Scanner(System.in);
		System.out.print("*  请输入选项:");
		String time = null;
		int a;
		do {
			a = sa.nextInt();
			switch (a) {
			case 1:
				//创建写好的自动生成系统时间类的对象，调用其方法
				Day da = new Day();
				time = da.Da();
				System.out.println(time);
				break;
			case 2:
				Scanner s = new Scanner(System.in);
				System.out.print("请输入时间");
				time = s.nextLine();
				break;
			}
			if (a != 1 && a != 2)
				System.out.print("请重新输入:");
		} while (a != 1 && a != 2);
		str.setSum(sum);
		str.setType(Data.type);
		str.setEntry(Data.entry);
		str.setTime(time);
		Data.Write(str.sum, str.type, str.entry, str.time);
		System.out.println("添加此流水成功！");
		Return re = new Return();
		re.Retu4();//创建返回类的对象，调用其返回方法
	}

}
