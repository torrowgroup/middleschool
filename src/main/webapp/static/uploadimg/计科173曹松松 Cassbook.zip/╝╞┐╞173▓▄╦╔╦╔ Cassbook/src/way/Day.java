package way;
/*
 * 这是实现自动生成
 * 系统时间的类
 * 主要运用了日期的知识
 */
import java.util.Date;
import java.text.SimpleDateFormat;

public class Day {
	String today;
	public String Da() {
		Date date=new Date();
	    System.out.println(date);
	    //从机器日期转换为想要的这种格式
		SimpleDateFormat a=new SimpleDateFormat("yyyy年MM月dd日  HH:mm:ss");
		today=a.format(date);
		return today;
	}
}
