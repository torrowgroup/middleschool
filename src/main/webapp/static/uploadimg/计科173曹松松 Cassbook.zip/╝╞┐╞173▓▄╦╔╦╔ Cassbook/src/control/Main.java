package control;
/*
 * 主类
 */
import way.Forget;

public class Main {
	public static void main(String[] args) throws Exception {
		Forget fo = new Forget();
		fo.forge();

	}
}
