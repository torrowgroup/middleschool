﻿package way;
/*
 * 此类主要封装了修改密码，修改密保答案的方法
 * 主要运用了io流的知识
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import practical.Land;

@SuppressWarnings("serial")
public class Passwords implements java.io.Serializable {
	static Land den = new Land();
    static Return re=new Return();
    //这是修改密码的方法
	public String Xiugai() throws Exception {
		Return re = new Return();
		Scanner sca=new Scanner(System.in);
		System.out.print("请输入旧密码:");
		String password=sca.nextLine();
		if(password.equals(den.password)){
		System.out.print("请输入新密码:");
		Read();
		Scanner xin = new Scanner(System.in);
		String mi1 = xin.nextLine();
		den.setPassword(mi1);
		Write();
		System.out.println("修改密码成功，请牢记你的密码！");
		}
		else
			System.out.println("密码不正确！");
			re.Retu5();
		return den.password;
	}

	@SuppressWarnings("unchecked")
	//这是重写的read方法
	public static void Read() throws IOException {
		FileInputStream fi = null;
		ObjectInputStream ob = null;
		File file = new File("D:\\test\\shuju.java");
		try {
			fi = new FileInputStream(file);
			ob = new ObjectInputStream(fi);
			den.password = (String) ob.readObject();
			ob.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
   //这是重写的write方法
	public static void Write() {
		FileOutputStream fo = null;
		ObjectOutputStream out = null;
		File file1 = new File("D:\\test\\shuju.java");
		try {
			fo = new FileOutputStream(file1);
			out = new ObjectOutputStream(fo);
			out.writeObject(den.password);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	//这是修改密保答案的方法
	public static void Security() throws Exception{
		BufferedReader buff1=new BufferedReader(new FileReader("D:\\test\\forget.java"));
		BufferedWriter buff2=new BufferedWriter(new FileWriter("D:\\test\\forget"));
		char[] a=new char[100];
		int i=buff1.read(a);
		String secur=new String(a,0,i);
		System.out.println(secur);
		buff2.flush();
		buff1.close();
		Scanner read=new Scanner(System.in);
		System.out.println("请输入旧密保");
		String jiu=read.nextLine();
		if(jiu.equals(secur)){
			System.out.println("请输入新密保答案");
			Scanner scan=new Scanner(System.in);
			String xin=read.nextLine();
			buff2.write(xin);
			buff2.flush();
			buff2.close();
			System.out.println("修改密保成功");
			re.Retu5();
		}
		else
			re.Retu5();
		
	}
	

}
