package control;
/*
 * 这是实现登陆的类
 * 主要运用了for和判断语句
 */
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Scanner;

import practical.Land;
import practical.Homepage;
import way.Validate;

@SuppressWarnings("unused")
public class Landing {

	@SuppressWarnings("static-access")
	public void Deng() throws Exception {
		Land den = new Land("50", "cao1627");
		FileInputStream fi = new FileInputStream("D:\\test\\shuju.java");
		ObjectInputStream ob = new ObjectInputStream(fi);
		den.password = (String) ob.readObject();

		// System.out.println(den.password);

		Validate yan = new Validate();
		for (int i = 3; i >= 1; i--) {
			System.out.print("*  请输入你的登录账号: ");
			Scanner sca = new Scanner(System.in);
			den.Id = sca.nextLine();
			System.out.print("*  请输入你的密码: ");
			Scanner sc = new Scanner(System.in);
			//调用生成验证码的方法
			String a = sc.nextLine();
			yan.Yan();
			if (!den.Id.equals("cao1627") || !a.equals(den.password)) {
				System.out.println("你的账号或者密码不正确");
				System.out.println("你还有" + (i - 1) + "次机会");
				if (i == 0)
					System.out.println("登陆失败");
			} else {
				System.out.println("登陆成功！");
				//实现与主页连接
				Homepage ma = new Homepage();
				ma.Zhu();
				break;
			}
		}
	}
}
