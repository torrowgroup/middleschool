package way;
                          
import java.util.Scanner;          /*
                                    *这是实现验证码的类
                                    *里面有实现验证码的方法
                                    *主要运用了random的知识
                                    */

import control.Landing;

public class Validate {

	public void Yan() throws Exception{
		   Landing d=new Landing();
//		for(int j=1;j<=3;j++){
			long sui=(long)(Math.random()*(899999)+100000);
			System.out.println("*  验证码为:"+sui);
			Scanner s=new Scanner(System.in);
			System.out.print("*  请输入验证码:");
			long ji=s.nextLong();
			if(ji==sui){
				System.out.println("验证码输入正确");
//				break;
			}
			else{
			System.out.println("验证码错误,请重新输入");
			d.Deng();
//			System.out.println("你还有"+(j-1)+"次机会");
//			if(j==0)
//				System.out.println("验证码输入失败");
//			}		
			}
	}
}
