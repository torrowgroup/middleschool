package practical;
/*
 * 这是构架主页的类
 */
import java.io.Serializable;
import java.util.Scanner;

import way.Amend;
import way.Data;
import way.Day;
import way.Passwords;
import way.Return;

//import fangfa.Data;
@SuppressWarnings("serial")
public class Homepage implements Serializable {
	public void Zhu() throws Exception {
		Passwords fa = new Passwords();
		Land de = new Land();
		Stream str = new Stream();
		Data data = new Data();
		Return re = new Return();
		Day da = new Day();
		Amend am = new Amend();
		Scanner read = new Scanner(System.in);
		System.out.println("**********************************");
		System.out.println("********欢迎来到你温暖又贴心的记账本*******");
		System.out
				.println("********1: 录入                                 ********");
		System.out.println("********2: 删除流水                          ********");
		System.out.println("********3: 修改流水                          ********");
		System.out.println("********4: 查询流水                          ********");
		System.out.println("********5: 修改密码                          ********");
		System.out.println("********6: 修改密保                          ********");
		System.out.println("********7: 退出登录                          ********");
		System.out.print("请输入你想操作的功能号");
		int number;
		do {
			number = read.nextInt();
			switch (number) {
			case 1:
				Data.Choose();
				re.Retu();
				break;
			case 2:
				data.Delete();
				re.Retu();
				break;
			case 3:
				am.Amen();
				re.Retu();
				break;
			case 4:
				am.Inquire();
				re.Retu();
				break;
			case 5:
				fa.Xiugai();
				re.Retu();
				break;
			
			case 6:
				fa.Security();
				re.Retu();
				break;
			case 7:
				System.out.println("退出本次登录");
				break;

			}
			if (number != 1 && number != 2 && number != 3 && number != 4
					&& number != 5 && number != 6)
				System.out.println("你输入的格式有误，请输入数字格式");
		} while (number != 1 && number != 2 && number != 3 && number != 4
				&& number != 5 && number != 6);
	}

}
