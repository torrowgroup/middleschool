package practical;
/*
 * 这是定义密码，账号等属性的类
 */
public class Land implements LandInterfase {
	public static String password;
	public static String Id;

	public Land(String password, String Id) {
		this.password = password;
		this.Id = Id;
	}

	public Land() {
	}

	public String getPassword(String password) {
		return password;
	}

	public String getId(String Id) {
		return Id;
	}

	public void setPassword(String g) {
		this.password = g;
	}

}
